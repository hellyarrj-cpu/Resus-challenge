# Dr Ricky's Resus Challenge — deployment guide

This is the standalone version of the game, ready to deploy for free on
Vercel or Netlify, using Supabase to save progress and the leaderboard.

## 1. Set up Supabase (5 minutes)

1. Go to supabase.com → sign up → "New project"
2. Set a database password (save it somewhere safe) and create the project
3. Once it's ready, open the **SQL Editor** (left sidebar) → "New query"
4. Paste this in and click **Run**:

```sql
create table kv_store (
  key text not null,
  scope text not null,
  value jsonb not null,
  updated_at timestamptz default now(),
  primary key (key, scope)
);

alter table kv_store enable row level security;

create policy "public read/write"
  on kv_store
  for all
  using (true)
  with check (true);
```

This creates one simple table that stores both personal progress and the
shared leaderboard. The policy above allows anyone with your public anon
key to read/write — fine for a free educational tool with no login, but
worth knowing (see "A note on the open policy" at the bottom).

5. Go to **Project Settings → API**. Copy the **Project URL** and the
   **anon public** key — you'll need both in step 3.

## 2. Push the code to GitHub

1. Go to github.com → create a new empty repository, e.g. `resus-challenge`
2. In this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/resus-challenge.git
git push -u origin main
```

(If you don't have `git` installed or aren't comfortable with the command
line, GitHub Desktop or the "upload files" button on github.com both work
too — just make sure `.env` is never uploaded, it's already in
`.gitignore`.)

## 3. Deploy on Vercel (or Netlify)

**Vercel:**
1. vercel.com → sign up/log in with GitHub
2. "Add New… → Project" → select your `resus-challenge` repo → Import
3. It auto-detects Vite. Before deploying, open **Environment Variables** and add:
   - `VITE_SUPABASE_URL` = (from step 1)
   - `VITE_SUPABASE_ANON_KEY` = (from step 1)
4. Click **Deploy**. You'll get a live URL like `resus-challenge.vercel.app`

**Netlify (alternative):**
1. netlify.com → "Add new site" → "Import an existing project" → connect your GitHub repo
2. Build command: `npm run build`, publish directory: `dist`
3. Site settings → Environment variables → add the same two `VITE_SUPABASE_*` values
4. Deploy

## 4. Add your own domain (optional)

If you want it at something like `resus.reflectionguide.com`, add that as
a custom domain in your Vercel/Netlify project settings, then add the CNAME
record they give you to reflectionguide.com's DNS settings.

## Local development

```bash
npm install
cp .env.example .env   # then fill in your Supabase values
npm run dev
```

## A note on the open policy

The SQL above uses a fully open read/write policy so the game works
without requiring players to log in. This is a reasonable trade-off for a
free educational tool with no sensitive data (just game progress and
scores), but it does mean anyone with your public anon key could
technically write to that table. If this ever matters more (e.g. you want
tamper-proof leaderboards), the fix is to move leaderboard writes through
a Supabase Edge Function instead of writing directly from the browser —
worth revisiting if the game gets wider adoption.
